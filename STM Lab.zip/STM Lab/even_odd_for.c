//#include<stdio.h>
//void main()
//{
//	int i,n=5,j=0;
//	printf("enter a number:");
//	scanf("%d",&i);
//	for( ; i>0 && j<n ;i++,j++ )
//	{
//		if(i%2==0)
//		{
//			printf("%d is even\n",i);
//		}
//		else
//		{
//			printf("%d is odd\n",i);
//		}
//	
//   }
//}

#include<stdio.h>
void main()
{
	int i,n;
	scanf("%d",&n);
	for(i=n;i<=n+5;i++)
	{
		if(i%2==0)
		{
			printf("%d is even\n",i);
		}
		else
		{
			printf("%d is odd\n",i);
		}
	
    }
}


