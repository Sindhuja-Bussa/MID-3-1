#include <stdio.h>

int main()
{
    int a,b,c,i;
    printf("1.add\n 2.sub\n 3.mul\n 4.div\n Enter the choice");
    scanf("%d",&i);
    printf("Enter a and b values");
    scanf("%d%d",&a,&b);
    switch(i)
    {
        case 1 : c=a+b;
        printf("Addition %d",c);
        break;
        
        case 2: c=a-b;
        printf("Substraction %d",c);
        break;
        
        case 3: c=a*b;
        printf("Multiplication %d",c);
        break;
        
        case 4: c=a/b;
        printf("Division %d",c);
        break;
    }
  
    return 0;
}
