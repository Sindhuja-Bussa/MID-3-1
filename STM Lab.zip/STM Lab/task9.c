#include<stdio.h> 
#include<conio.h> 
void main() 
{ 
int a[3][3],b[3][3],c[3][3],i,j,k,m,n,p,q; 
printf("Enter matrix no.of rows & cols"); 
scanf("%d%d",&m,&n); 
printf("Enter 2matrix no.of rows & cols") ; 
scanf("%d%d",&p,&q); 
printf("\n enter the matrix elements"); 
for(i=0;i<m;i++) 
{ 
for(j=0;j<n;j++) 
{ 
scanf("%d",&a[i][j]); 
} 
} 
printf("\n a matrix is\n"); 
for(i=0;i<m;i++) 
{ 
for(j=0;j<n;j++) 
{ 
printf("%d\t",a[i][j]); 
} 
printf("\n"); 
} 
for(i=0;i<p;i++) 
{ 
for(j=0;j<q;j++) 
{ 
scanf("%d\t",&b[i][j]); 
} 
} 
printf("\n b matrix is\n"); 
for(i=0;i<p;i++) 
{ 
for(j=0;j<q;j++) 
{ 
printf("%d\t",b[i][j]); 
} 
printf("\n"); 
} 
for(i=0;i<m;i++) 
{ 
for(j=0;j<q;j++) 
{ 
c[i][j]=0; for(k=0;k<n;k++) 
{ 
c[i][j]=c[i][j]+a[i][k]*b[k][j]; 
} 
} 
} 
for(i=0;i<m;i++) 
{ 
for(j=0;j<q;j++) 
{ 
printf("%d\t",c[i][j]); 
} 
printf("\n"); 
} 
getch(); 
}
