#include<stdio.h>
void main()
{
	int i,n=5,j=0;
	printf("enter a number:");
	scanf("%d",&i);
	do
	{
		if(i%2==0)
		{
			printf("%d is even\n",i);
			i++;
			j++;
		}
		else
		{
			printf("%d is odd\n",i);
			i++;
			j++;
		}
	}while(i>0 && j<n);
}
